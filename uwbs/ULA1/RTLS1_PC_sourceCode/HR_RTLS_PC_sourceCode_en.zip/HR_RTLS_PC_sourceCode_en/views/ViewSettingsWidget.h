// -------------------------------------------------------------------------------------------------------------------
//
//  File: ViewSettingsWidget.h
//
//  Copyright 2016 (c) Decawave Ltd, Dublin, Ireland.
//
//  All rights reserved.
//
//  Author:
//
// -------------------------------------------------------------------------------------------------------------------

#ifndef VIEWSETTINGSWIDGET_H
#define VIEWSETTINGSWIDGET_H

#include <QWidget>
#include "SerialConnection.h"
#include "ui_ViewSettingsWidget.h"
#include <QDomElement>         //新增
#include "GraphicsWidget.h"
#include <QSerialPort>
#include <QSerialPortInfo>
extern GraphicsWidget *myGraphicsWidget;
namespace Ui {
class ViewSettingsWidget;
}

class ViewSettingsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ViewSettingsWidget(QWidget *parent = 0);
    ~ViewSettingsWidget();

    int applyFloorPlanPic(const QString &path);
    static ViewSettingsWidget *viewsettingswidget;//!!!!!!!!!指针类型静态成员变量
public:

   // SerialConnection *myCom;

public slots:
    void connectionStateChanged(SerialConnection::ConnectionState state);
    void serialError();
    int updateDeviceList();
    void setLinetext(QString s);

signals:
    void saveViewSettings(void);
   // void SystemResponse();//系统响应
protected slots:
    void onReady();

    void enableAutoPositioning(int enable);

    void floorplanOpenClicked();
    void updateLocationFilter(int index);
    void enableFiltering(void);
    void originClicked();
    void scaleClicked();

    void gridShowClicked();
    void originShowClicked();
    void tagHistoryShowClicked();

    void saveFPClicked();
    void tagAncTableShowClicked();
    void useAutoPosClicked();
    void showGeoFencingModeClicked();
    void showNavigationModeClicked();
    void alarmSetClicked();

    void zone1ValueChanged(double);
    void zone2ValueChanged(double);
    void zone1EditFinished(void);
    void zone2EditFinished(void);
    void tagHistoryNumberValueChanged(int);

    void showOriginGrid(bool orig, bool grid);
    void getFloorPlanPic(void);
    void showSave(bool);

    void setTagHistory(int h);
    void loggingClicked(void);
    void connectButtonClicked();
    void on_Tag_size_valueChanged(double arg1);


public:

    Ui::ViewSettingsWidget *ui;

private slots:
    void dataupdate();
    void on_pushButton_clicked();
    void on_socket_pb_clicked(bool checked);
    void on_BTN_getdata_clicked();



    void on_BTN_addr_clicked();
    void Settimeout();
    void on_BTN_ant_dly_ok_clicked();

    void on_lE_tx_power_ok_clicked();
    void on_BTN_Restore_clicked();

    void on_BTN_jizhan_clicked();


    void on_BTN_tongbu_clicked();

private:
    SerialConnection mySerialConnection;
    SerialConnection::ConnectionState _state;

    bool _logging ;
    bool _floorplanOpen ;
    bool _enableAutoPos;
    bool fucStatus;
    int _selected;
    QTimer *timer;
    QStringList oldPortStringList;
    QStringList newPortStringList;

    QTimer *m_setTimer;
    void updatedata();

};

#endif // VIEWSETTINGSWIDGET_H
