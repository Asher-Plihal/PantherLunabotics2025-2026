// -------------------------------------------------------------------------------------------------------------------
//
//  File: ViewSettingsWidget.cpp
//
//  Copyright 2016 (c) Decawave Ltd, Dublin, Ireland.
//
//  All rights reserved.
//
//  Author:
//
// -------------------------------------------------------------------------------------------------------------------


#include "ui_GraphicsWidget.h"
#include "ViewSettingsWidget.h"
#include "ui_ViewSettingsWidget.h"

#include "RTLSDisplayApplication.h"
#include "QPropertyModel.h"
#include "ViewSettings.h"
#include "OriginTool.h"
#include "ScaleTool.h"
#include "GraphicsView.h"
#include "GraphicsWidget.h"
#include "mainwindow.h"
#include <QTimer>
#include <QFileDialog>
#include <QMessageBox>
#include <QProcess>
#include <QHostInfo>
//QString Rev_$setok;

bool serial_connected = false;
extern QString port_name;

ViewSettingsWidget *ViewSettingsWidget::viewsettingswidget = nullptr;
ViewSettingsWidget::ViewSettingsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ViewSettingsWidget),
    _floorplanOpen(false)
{
    ui->setupUi(this);
    viewsettingswidget = this;

    //mySerialConnection->ViewSettingsWidgetUi =ui;
    //ui->tabWidget->setCurrentIndex(0);
    //ui->tabWidget->removeTab(2);

    QObject::connect(RTLSDisplayApplication::serialConnection(),SIGNAL(dataupdate()),SLOT(dataupdate()));

    QObject::connect(ui->connect_pb, SIGNAL(clicked()), SLOT(connectButtonClicked()));  //add a function for the Connect button click

    QObject::connect(ui->floorplanOpen_pb, SIGNAL(clicked()), this, SLOT(floorplanOpenClicked()));

    QObject::connect(ui->scaleX_pb, SIGNAL(clicked()), this, SLOT(scaleClicked()));
    QObject::connect(ui->scaleY_pb, SIGNAL(clicked()), this, SLOT(scaleClicked()));
    QObject::connect(ui->origin_pb, SIGNAL(clicked()), this, SLOT(originClicked()));

    QObject::connect(ui->saveFP, SIGNAL(clicked()), this, SLOT(saveFPClicked()));
    QObject::connect(ui->gridShow, SIGNAL(clicked()), this, SLOT(gridShowClicked()));
    QObject::connect(ui->showOrigin, SIGNAL(clicked()), this, SLOT(originShowClicked()));
    QObject::connect(ui->showTagHistory, SIGNAL(clicked()), this, SLOT(tagHistoryShowClicked()));
    QObject::connect(ui->showGeoFencingMode, SIGNAL(clicked()), this, SLOT(showGeoFencingModeClicked()));
    QObject::connect(ui->showNavigationMode, SIGNAL(clicked()), this, SLOT(showNavigationModeClicked()));

    QObject::connect(ui->useAutoPos, SIGNAL(clicked()), this, SLOT(useAutoPosClicked()));
    QObject::connect(ui->showTagTable, SIGNAL(clicked()), this, SLOT(tagAncTableShowClicked()));
    QObject::connect(ui->showAnchorTable, SIGNAL(clicked()), this, SLOT(tagAncTableShowClicked()));
    QObject::connect(ui->showAnchorTagCorrectionTable, SIGNAL(clicked()), this, SLOT(tagAncTableShowClicked()));

    QObject::connect(ui->zone1, SIGNAL(editingFinished()), this, SLOT(zone1EditFinished()));
    QObject::connect(ui->zone2, SIGNAL(editingFinished()), this, SLOT(zone2EditFinished()));

    QObject::connect(ui->zone1, SIGNAL(valueChanged(double)), this, SLOT(zone1ValueChanged(double)));
    QObject::connect(ui->zone2, SIGNAL(valueChanged(double)), this, SLOT(zone2ValueChanged(double)));
    QObject::connect(ui->inAlarm, SIGNAL(clicked()), this, SLOT(alarmSetClicked()));
    QObject::connect(ui->outAlarm, SIGNAL(clicked()), this, SLOT(alarmSetClicked()));

    QObject::connect(ui->tagHistoryN, SIGNAL(valueChanged(int)), this, SLOT(tagHistoryNumberValueChanged(int)));

    QObject::connect(RTLSDisplayApplication::viewSettings(), SIGNAL(showSave(bool)), this, SLOT(showSave(bool)));
    QObject::connect(RTLSDisplayApplication::viewSettings(), SIGNAL(showGO(bool, bool)), this, SLOT(showOriginGrid(bool, bool)));
    QObject::connect(RTLSDisplayApplication::viewSettings(), SIGNAL(setFloorPlanPic()), this, SLOT(getFloorPlanPic()));
    QObject::connect(RTLSDisplayApplication::client(), SIGNAL(enableFiltering()), this, SLOT(enableFiltering()));

    QObject::connect(ui->logging_pb, SIGNAL(clicked()), this, SLOT(loggingClicked()));

    QObject::connect(RTLSDisplayApplication::client(), SIGNAL(enableAutoPositioning(int)), this, SLOT(enableAutoPositioning(int)));

   //获取IPv4 ip地址
    QString localHostName = QHostInfo::localHostName();
    QHostInfo info = QHostInfo::fromName(localHostName);
    foreach(QHostAddress address,info.addresses())
    {
    if(address.protocol() == QAbstractSocket::IPv4Protocol)
        ui->ip_address->addItem(address.toString());
    //ui->ip_address->setText(address.toString());
    }

    //  赋值点大小
  //  ui->tag_size->setText(QString("%2").arg(GraphicsWidget::_tagSize));
  //  cout<<"1234567897897654564"<<GraphicsWidget::_tagSize<<endl;
    _logging = false;

    ui->label_logfile->setText("");
    if(_logging)
    {
        ui->logging_pb->setText("Stop");
        ui->label_logingstatus->setText("Logging enabled.");
    }
    else
    {
        ui->logging_pb->setText("Start");
        ui->label_logingstatus->setText("Logging disabled.");
    }

    _enableAutoPos = false; //auto positioning only works when connected to Anchor #0, so it is disabled until connected to Anchor #0
    ui->useAutoPos->setDisabled(true);

    ui->connect_pb->setEnabled(true);
    ui->label->setEnabled(true);
    ui->comPort->setEnabled(true);

    _selected = 0;
    fucStatus = false;
    RTLSDisplayApplication::connectReady(this, "onReady()");

  /*  */
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
       // qDebug() << "Name        : " << info.portName();
       // qDebug() << "Description : " << info.description();
       // qDebug() << "Manufacturer: " << info.manufacturer();

        // Example use QSerialPort
        QSerialPort serial;
        serial.setPort(info);
        if (serial.open(QIODevice::ReadWrite))
        {   ui->comPort->addItem(info.portName());

            serial.close();
        }
    }
    /*  */
}

void ViewSettingsWidget::onReady()
{
    qDebug() << "onReady()";
    QPropertyDataWidgetMapper *mapper = QPropertyModel::newMapper(RTLSDisplayApplication::viewSettings(), this);
    mapper->addMapping(ui->gridWidth_sb, "gridWidth");
    mapper->addMapping(ui->gridHeight_sb, "gridHeight");

    mapper->addMapping(ui->floorplanFlipX_cb, "floorplanFlipX", "checked");
    mapper->addMapping(ui->floorplanFlipY_cb, "floorplanFlipY", "checked");
    mapper->addMapping(ui->gridShow, "showGrid", "checked");
    mapper->addMapping(ui->showOrigin, "showOrigin", "checked");

    mapper->addMapping(ui->floorplanXOff_sb, "floorplanXOffset");
    mapper->addMapping(ui->floorplanYOff_sb, "floorplanYOffset");

    mapper->addMapping(ui->floorplanXScale_sb, "floorplanXScale");
    mapper->addMapping(ui->floorplanYScale_sb, "floorplanYScale");
    mapper->toFirst();

    QObject::connect(ui->floorplanFlipX_cb, SIGNAL(clicked()), mapper, SLOT(submit())); // Bug with QDataWidgetMapper (QTBUG-1818)
    QObject::connect(ui->floorplanFlipY_cb, SIGNAL(clicked()), mapper, SLOT(submit()));
    QObject::connect(ui->gridShow, SIGNAL(clicked()), mapper, SLOT(submit())); // Bug with QDataWidgetMapper (QTBUG-1818)
    QObject::connect(ui->showOrigin, SIGNAL(clicked()), mapper, SLOT(submit()));

    QObject::connect(RTLSDisplayApplication::serialConnection(), SIGNAL(connectionStateChanged(SerialConnection::ConnectionState)),
                     this, SLOT(connectionStateChanged(SerialConnection::ConnectionState)));


    
    //by default the Geo-Fencing is OFF

    ui->showTagHistory->setChecked(true);

    ui->zone1->setDisabled(true);
    ui->zone2->setDisabled(true);
    ui->label_z1->setDisabled(true);
    ui->label_z2->setDisabled(true);
    ui->outAlarm->setDisabled(true);
    ui->inAlarm->setDisabled(true);

    ui->tabWidget->setCurrentIndex(0);

    RTLSDisplayApplication::graphicsWidget()->zone1Value(ui->zone1->value());
    RTLSDisplayApplication::graphicsWidget()->zone2Value(ui->zone2->value());
    RTLSDisplayApplication::graphicsWidget()->setAlarm(ui->inAlarm->isChecked(), ui->outAlarm->isChecked());

    ui->filtering->setEnabled(false);
    ui->filtering->addItems(RTLSDisplayApplication::client()->getLocationFilters());
    ui->filtering->setCurrentIndex(2);
    QObject::connect(ui->filtering, SIGNAL(currentIndexChanged(int)), this, SLOT(updateLocationFilter(int)));

    ViewSettingsWidget::updateDeviceList();
    oldPortStringList = RTLSDisplayApplication::serialConnection()->portsList();
   // ui->comPort->addItems(oldPortStringList);
   // qDebug()<<"oldPortStringList"<<oldPortStringList;

    timer = new QTimer;
    QObject::connect(timer,&QTimer::timeout,this,&ViewSettingsWidget::updateDeviceList);//更新后台端口号
    timer->start(1000); // 使用定时器 1秒读取一次后台设备管理器

    connectionStateChanged(SerialConnection::Disconnected);

    m_setTimer =new QTimer;
}

int ViewSettingsWidget::updateDeviceList()
{
    int count = 0;
    //if(serial_connected == false) 
    {
        RTLSDisplayApplication::serialConnection()->findSerialDevices();
        newPortStringList = RTLSDisplayApplication::serialConnection()->portsList();
    
        if(newPortStringList.size() != oldPortStringList.size())
        {
            oldPortStringList = newPortStringList;
            ui->comPort->clear();
            ui->comPort->addItems(oldPortStringList);
        }
    }

    count = ui->comPort->count();
    //qDebug()<<"port count="<<count;
    // qDebug() << "port_num = " << port_name;
    // qDebug() << "newPortStringList = " << newPortStringList;
    // if(newPortStringList.contains(port_name))
    // {
    //     qDebug() << "contains";
    // }
    //check if we have found any TREK devices in the COM ports list
    if((count == 0) || ((!newPortStringList.contains(port_name)) && (port_name!="")))
    {
        qDebug() << "close serial port";
        //ui->connect_pb->setEnabled(false);
        ui->label->setEnabled(false);
        ui->comPort->setEnabled(false);
        RTLSDisplayApplication::serialConnection()->closeConnection();
        port_name = "";

        // connectionStateChanged(SerialConnection::Disconnected);
        // RTLSDisplayApplication::mainWindow()->connectionStateChanged(SerialConnection::Disconnected);
    }


    return count;
}

void ViewSettingsWidget::serialError(void)
{
    ui->connect_pb->setEnabled(false);
    ui->label->setEnabled(false);
    ui->comPort->setEnabled(false);
}


void ViewSettingsWidget::connectButtonClicked()
{

    switch (_state)
    {
    case SerialConnection::Disconnected:
    case SerialConnection::ConnectionFailed:
    {
        RTLSDisplayApplication::serialConnection()->openConnection(ui->comPort->currentIndex());
        break;
    }

    case SerialConnection::Connecting:
        RTLSDisplayApplication::serialConnection()->cancelConnection();
        break;

    case SerialConnection::Connected:
        RTLSDisplayApplication::serialConnection()->closeConnection();
        break;
    }

}

void ViewSettingsWidget::connectionStateChanged(SerialConnection::ConnectionState state)
{
    this->_state = state;
    switch(state)
    {
    case SerialConnection::Disconnected:
    case SerialConnection::ConnectionFailed:
        ui->connect_pb->setText("Connect");
        ui->BTN_getdata->setEnabled(false);
        ui->BTN_Restore->setEnabled(false);
        ui->BTN_tongbu->setEnabled(false);
        ui->BTN_jizhan->setEnabled(false);
        ui->BTN_addr->setEnabled(false);
        ui->BTN_ant_dly_ok->setEnabled(false);
        ui->lE_tx_power_ok->setEnabled(false);

        //this->show();
        break;

    case SerialConnection::Connecting:
        ui->connect_pb->setText("Cancel");
        //this->show();
        break;

    case SerialConnection::Connected:
        ui->connect_pb->setText("Disconnect");
        ui->BTN_getdata->setEnabled(true);
        ui->BTN_Restore->setEnabled(true);
        ui->BTN_tongbu->setEnabled(true);
        ui->BTN_ant_dly_ok->setEnabled(true);
        ui->lE_tx_power_ok->setEnabled(true);
        //this->hide();
        break;
    }

    bool enabled = (state == SerialConnection::Disconnected || state == SerialConnection::ConnectionFailed) ? true : false;
    //can change the COM port once not opened
    ui->comPort->setEnabled(enabled);
    //cout<<enabled<<endl;
    if(enabled == 0){
        ui->socket_pb->setEnabled(0);
    }
    else{
        ui->socket_pb->setEnabled(1);
    }

}


ViewSettingsWidget::~ViewSettingsWidget()
{
    delete ui;
}


void ViewSettingsWidget::enableFiltering(void)
{
     ui->filtering->setEnabled(true);
}

void ViewSettingsWidget::updateLocationFilter(int index)
{
     RTLSDisplayApplication::client()->setLocationFilter(index);
}

int ViewSettingsWidget::applyFloorPlanPic(const QString &path)
{
    QPixmap pm(path);

    if (pm.isNull())
    {
        //QMessageBox::critical(this, "Could not load floor plan", QString("Failed to load image : %1").arg(path));
        return -1;
    }

    ui->floorplanPath_lb->setText(QFileInfo(path).fileName());
    RTLSDisplayApplication::viewSettings()->setFloorplanPixmap(pm);
    _floorplanOpen = true;
    ui->floorplanOpen_pb->setText("清除");

    return 0;
}

void ViewSettingsWidget::getFloorPlanPic()
{
    applyFloorPlanPic(RTLSDisplayApplication::viewSettings()->getFloorplanPath());
}

void ViewSettingsWidget::floorplanOpenClicked()
{
    if(_floorplanOpen == false)
    {
        QString path = QFileDialog::getOpenFileName(this, "Open Bitmap", QString(), "Image (*.png *.jpg *.jpeg *.bmp)");
        if (path.isNull()) return;

        if(applyFloorPlanPic(path) == 0) //if OK set/save the path string
        {
            RTLSDisplayApplication::viewSettings()->floorplanShow(true);
            RTLSDisplayApplication::viewSettings()->setFloorplanPath(path);
        }
        _floorplanOpen = true;
        ui->floorplanOpen_pb->setText("Clear");
    }
    else
    {
       RTLSDisplayApplication::viewSettings()->floorplanShow(false);
       RTLSDisplayApplication::viewSettings()->clearSettings();
       _floorplanOpen = false;
       ui->floorplanOpen_pb->setText("Open");
       ui->floorplanFlipX_cb->setChecked(false);
       ui->floorplanFlipY_cb->setChecked(false);
       ui->floorplanXScale_sb->setValue(0.0);
       ui->floorplanYScale_sb->setValue(0.0);
       ui->floorplanXOff_sb->setValue(0.0);
       ui->floorplanYOff_sb->setValue(0.0);
       ui->floorplanPath_lb->setText("");
    }
}

void ViewSettingsWidget::showOriginGrid(bool orig, bool grid)
{
    Q_UNUSED(orig)

    ui->gridShow->setChecked(grid);
    ui->showOrigin->setChecked(orig);
}

void ViewSettingsWidget::gridShowClicked()
{
    RTLSDisplayApplication::viewSettings()->setShowGrid(ui->gridShow->isChecked());
}

void ViewSettingsWidget::originShowClicked()
{
    RTLSDisplayApplication::viewSettings()->setShowOrigin(ui->showOrigin->isChecked());
}

void ViewSettingsWidget::showNavigationModeClicked()
{
    if(ui->showNavigationMode->isChecked())
    {
        ui->showGeoFencingMode->setChecked(false);
        showGeoFencingModeClicked();
    }
    else
    {
        ui->showGeoFencingMode->setChecked(true);
        showGeoFencingModeClicked();
    }
}


void ViewSettingsWidget::showGeoFencingModeClicked()
{
    RTLSDisplayApplication::graphicsWidget()->showGeoFencingMode(ui->showGeoFencingMode->isChecked());

    if(ui->showGeoFencingMode->isChecked())
    {
        ui->showTagHistory->setDisabled(true);
        ui->tagHistoryN->setDisabled(true);

        ui->zone1->setEnabled(true);
        ui->zone2->setEnabled(true);
        ui->label_z1->setEnabled(true);
        ui->label_z2->setEnabled(true);
        ui->outAlarm->setEnabled(true);
        ui->inAlarm->setEnabled(true);

        ui->showNavigationMode->setChecked(false);

        if(_enableAutoPos)
        {
            //set auto positioning to off when in geo-fencing mode
            RTLSDisplayApplication::client()->setUseAutoPos(false);
            ui->useAutoPos->setDisabled(true);
        }
    }
    else
    {
        ui->showTagHistory->setDisabled(false);
        ui->tagHistoryN->setDisabled(false);

        ui->zone1->setDisabled(true);
        ui->zone2->setDisabled(true);
        ui->label_z1->setDisabled(true);
        ui->label_z2->setDisabled(true);
        ui->outAlarm->setDisabled(true);
        ui->inAlarm->setDisabled(true);

        if(_enableAutoPos)
        {
            ui->useAutoPos->setDisabled(false);
            useAutoPosClicked();
        }

        ui->showNavigationMode->setChecked(true);
    }

}

void ViewSettingsWidget::enableAutoPositioning(int enable)
{
    _enableAutoPos = enable;
    ui->useAutoPos->setDisabled(!enable);
}

void ViewSettingsWidget::tagHistoryNumberValueChanged(int value)
{
    RTLSDisplayApplication::graphicsWidget()->tagHistoryNumber(value);
}

void ViewSettingsWidget::zone1EditFinished(void)
{
    RTLSDisplayApplication::graphicsWidget()->zone1Value(ui->zone1->value());
}

void ViewSettingsWidget::zone2EditFinished(void)
{
    RTLSDisplayApplication::graphicsWidget()->zone2Value(ui->zone2->value());
}

void ViewSettingsWidget::zone1ValueChanged(double value)
{
    RTLSDisplayApplication::graphicsWidget()->zone1Value(value);
}

void ViewSettingsWidget::zone2ValueChanged(double value)
{
    RTLSDisplayApplication::graphicsWidget()->zone2Value(value);
}

void ViewSettingsWidget::useAutoPosClicked()
{
    RTLSDisplayApplication::client()->setUseAutoPos(ui->useAutoPos->isChecked());

    RTLSDisplayApplication::graphicsWidget()->anchTableEditing(!ui->useAutoPos->isChecked());
}

void ViewSettingsWidget::tagAncTableShowClicked()
{
    RTLSDisplayApplication::graphicsWidget()->setShowTagAncTable(ui->showAnchorTable->isChecked(),
                                                                 ui->showTagTable->isChecked(),
                                                                 ui->showAnchorTagCorrectionTable->isChecked());
}

void ViewSettingsWidget::setTagHistory(int h)
{
    ui->tagHistoryN->setValue(h);
}


void ViewSettingsWidget::tagHistoryShowClicked()
{
    RTLSDisplayApplication::graphicsWidget()->setShowTagHistory(ui->showTagHistory->isChecked());
}


void ViewSettingsWidget::loggingClicked(void)
{
    if(_logging == false)
    {
        _logging = true ;
        RTLSDisplayApplication::client()->openLogFile("");
        ui->logging_pb->setText("Stop");
        ui->label_logingstatus->setText("Logging enabled.");
        ui->label_logfile->setText(RTLSDisplayApplication::client()->getLogFilePath());
    }
    else
    {
        RTLSDisplayApplication::client()->closeLogFile();
        ui->logging_pb->setText("Start");
        ui->label_logingstatus->setText("Logging disabled.");
        ui->label_logfile->setText("");
        ui->saveFP->setChecked(false);
        _logging = false ;
    }
}


void ViewSettingsWidget::alarmSetClicked()
{
    RTLSDisplayApplication::graphicsWidget()->setAlarm(ui->inAlarm->isChecked(), ui->outAlarm->isChecked());
}

void ViewSettingsWidget::saveFPClicked()
{
    RTLSDisplayApplication::viewSettings()->setSaveFP(ui->saveFP->isChecked());

    if(ui->saveFP->isChecked())
    {
        //save the current settings when clicked
       emit saveViewSettings();
    }
}

void ViewSettingsWidget::showSave(bool save)
{
    ui->saveFP->setChecked(save);
}

void ViewSettingsWidget::originClicked()
{
    OriginTool *tool = new OriginTool(this);
    QObject::connect(tool, SIGNAL(done()), tool, SLOT(deleteLater()));
    RTLSDisplayApplication::graphicsView()->setTool(tool);
}

void ViewSettingsWidget::scaleClicked()
{
    ScaleTool *tool = NULL;

    if (QObject::sender() == ui->scaleX_pb)
        tool = new ScaleTool(ScaleTool::XAxis, this);
    else if (QObject::sender() == ui->scaleY_pb)
        tool = new ScaleTool(ScaleTool::YAxis, this);

    QObject::connect(tool, SIGNAL(done()), tool, SLOT(deleteLater()));
    RTLSDisplayApplication::graphicsView()->setTool(tool);
}




void ViewSettingsWidget::on_Tag_size_valueChanged(double arg1)
{
    QFile file("./TREKtag_config.xml");

    if (!file.open(QIODevice::ReadWrite))
    {
        qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg("./TREKtag_config.xml").arg(file.errorString())));
        return;
    }

    QDomDocument doc;
    QString error;
    if(!doc.setContent(&file))
    {
        file.close();
        //qDebug("123456");
        return;
    }
    file.close();
    QDomElement config = doc.documentElement();//获取根结点元素

    if( config.tagName() == "config" )
    {
        QDomNode n = config.firstChild();
        while( !n.isNull() )
        {
            QDomElement e = n.toElement();
            if( !e.isNull() )
            {
                if( e.tagName() == "tag_cfg" )
                {
                    QString oldpath= e.attribute("size");
                    //cout<<e.attribute("size").toStdString()<<endl;
                    e.setAttribute("size",arg1);
                    //cout<<e.attribute("size").toStdString()<<endl;

                    break ;
                }

            }

            n = n.nextSibling();
        }

    }

    QFile file1("./TREKtag_config.xml");
       if (!file1.open(QIODevice::WriteOnly | QFile::Truncate))
       {
           qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg("./TREKtag_config.xml").arg(file.errorString())));
       }

       QTextStream xmlWrite(&file1);
       doc.save(xmlWrite,1);
       file.close();
    GraphicsWidget().loadConfigFile("./TREKtag_config.xml");
    GraphicsWidget().saveConfigFile("./TREKtag_config.xml");
    qDebug("写入成功");
    QMessageBox messageBox(QMessageBox::NoIcon,
                              "Information", "Click YES button to restart and take effect",
                              QMessageBox::Yes | QMessageBox::No, NULL);
    int result=messageBox.exec();
    switch (result)
        {
        case QMessageBox::Yes:{
            QString program = QApplication::applicationFilePath();
            QStringList arguments = QApplication::arguments();
            QString workingDirectory = QDir::currentPath();
            QProcess::startDetached(program, arguments, workingDirectory);
            QApplication::exit();

            break;}
        case QMessageBox::No:
            qDebug()<<"NO";
            break;
        default:
            break;
        }
}

void ViewSettingsWidget::on_pushButton_clicked()
{
    float num;
    num = ui->tag_size->text().toFloat();
    QFile file("./TREKtag_config.xml");

    if (!file.open(QIODevice::ReadWrite))
    {
        qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg("./TREKtag_config.xml").arg(file.errorString())));
        return;
    }

    QDomDocument doc;
    QString error;
    if(!doc.setContent(&file))
    {
        file.close();
        //qDebug("123456");
        return;
    }
    file.close();
    QDomElement config = doc.documentElement();//获取根结点元素

    if( config.tagName() == "config" )
    {
        QDomNode n = config.firstChild();
        while( !n.isNull() )
        {
            QDomElement e = n.toElement();
            if( !e.isNull() )
            {
                if( e.tagName() == "tag_cfg" )
                {
                    QString oldpath= e.attribute("size");
                    //cout<<e.attribute("size").toStdString()<<endl;
                    e.setAttribute("size",num);
                    //cout<<e.attribute("size").toStdString()<<endl;

                    break ;
                }

            }

            n = n.nextSibling();
        }

    }

    QFile file1("./TREKtag_config.xml");
       if (!file1.open(QIODevice::WriteOnly | QFile::Truncate))
       {
           qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg("./TREKtag_config.xml").arg(file.errorString())));
       }

       QTextStream xmlWrite(&file1);
       doc.save(xmlWrite,1);
       file.close();
    GraphicsWidget().loadConfigFile("./TREKtag_config.xml");
    GraphicsWidget().saveConfigFile("./TREKtag_config.xml");
    qDebug("写入成功");
    QMessageBox messageBox(QMessageBox::NoIcon,
                              "Information", "Click YES button to restart and take effect",
                              QMessageBox::Yes | QMessageBox::No, NULL);
    int result=messageBox.exec();

    switch (result)
        {
        case QMessageBox::Yes:{
            QString program = QApplication::applicationFilePath();
            QStringList arguments = QApplication::arguments();
            QString workingDirectory = QDir::currentPath();
            QProcess::startDetached(program, arguments, workingDirectory);
            QApplication::exit();

            break;}
        case QMessageBox::No:
            qDebug()<<"NO";
            break;
        default:
            break;
        }
}
void ViewSettingsWidget::setLinetext(QString s)
{
    ui->tag_size->setText(s);
}


void ViewSettingsWidget::on_socket_pb_clicked(bool checked)
{
    ui->socket_pb->setCheckable(true);
    if(checked == 0){
        int port = ui->tcp_port->text().toInt();
        //cout<<port<<endl;
        RTLSDisplayApplication::serialConnection()->netConnect(port);
        ui->socket_pb->setText("Disconnect");
        ui->connect_pb->setEnabled(0);
    }
    else{
        RTLSDisplayApplication::serialConnection()->netClose();
        ui->socket_pb->setText("Connect");
        ui->connect_pb->setEnabled(1);
    }
}


void ViewSettingsWidget::on_BTN_getdata_clicked()
{
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    RTLSDisplayApplication::serialConnection()->writeData("$rboot\r\n");
    m_setTimer->start(5);
    if(SerialConnection::Rev_$setok =="$setok")
    {
        QMessageBox::information(this,"Information","Parameter acquisition succeeded","Close");
        SerialConnection::Rev_$setok = "";
    }
    else
    {
        m_setTimer->start(1000);
        connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
    }

}


void ViewSettingsWidget::on_BTN_addr_clicked()
{
    int addrtext =ui->lE_addr->text().toInt();
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    if(addrtext>=0 && addrtext <=100 )
    {
        RTLSDisplayApplication::serialConnection()->writeData("$saddr,"+ui->lE_addr->text().toUtf8()+"\r\n");
        m_setTimer->start(5);
        if(SerialConnection::Rev_$setok =="$setok")
        {
            QMessageBox::information(this,"Information","Set Success!","Close");
            SerialConnection::Rev_$setok = "";
        }
        else
        {
            m_setTimer->start(1000);
            connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
        }

    }
    else
    {
        QMessageBox::warning(this,"Warning","Input error, please check the correctness of the parameters","Close");
    }
}

void ViewSettingsWidget::on_BTN_ant_dly_ok_clicked()
{
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    QString ant_dlytest =ui->lE_ant_dly->text();
    if(ant_dlytest.toInt()>=0 && ant_dlytest.toInt() <=65535 )
    {
        RTLSDisplayApplication::serialConnection()->writeData("$santdly,"+ant_dlytest.toUtf8()+"\r\n");
        m_setTimer->start(5);
        if(SerialConnection::Rev_$setok =="$setok")
        {
            QMessageBox::information(this,"Information","Set Success!","Close");
            SerialConnection::Rev_$setok = "";
        }
        else
        {
            m_setTimer->start(1000);
            connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
        }
    }
    else
    {
        QMessageBox::warning(this,"Warning","Input error, please check the correctness of the parameters","Close");
    }
}

void ViewSettingsWidget::on_lE_tx_power_ok_clicked()
{
    //int ant_dlytest =ui->lE_ant_dly->text().toInt();
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    if(ui->lE_tx_power->text().length()==8 )
    {
        RTLSDisplayApplication::serialConnection()->writeData("$stxpwr,"+ui->lE_tx_power->text().toUtf8()+"\r\n");
        m_setTimer->start(5);
        if(SerialConnection::Rev_$setok =="$setok")
        {
            QMessageBox::information(this,"Information","Set Success!","Close");
            SerialConnection::Rev_$setok = "";
        }
        else
        {
            m_setTimer->start(1000);
            connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
        }
    }
    else
    {
        QMessageBox::warning(this,"Warning","Input error, please check the correctness of the parameters","Close");
    }
}
void ViewSettingsWidget::on_BTN_jizhan_clicked()
{
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    RTLSDisplayApplication::serialConnection()->writeData("$sanccd,"+ui->lE_A0X->text().toUtf8()
    +","+ui->lE_A0Y->text().toUtf8()+","+ui->lE_A0Z->text().toUtf8()
    +","+ui->lE_A1X->text().toUtf8()+","+ui->lE_A1Y->text().toUtf8()+","+ui->lE_A1Z->text().toUtf8()
    +","+ui->lE_A2X->text().toUtf8()+","+ui->lE_A2Y->text().toUtf8()+","+ui->lE_A2Z->text().toUtf8()
    +","+ui->lE_A3X->text().toUtf8()+","+ui->lE_A3Y->text().toUtf8()+","+ui->lE_A3Z->text().toUtf8()
                                                          +"\r\n");

    m_setTimer->start(5);
    if(SerialConnection::Rev_$setok =="$setok")
    {
        QMessageBox::information(this,"Information","Set Success!","Close");
        SerialConnection::Rev_$setok = "";
    }
    else
    {
        m_setTimer->start(1000);
        connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
    }

}
void ViewSettingsWidget::on_BTN_Restore_clicked()
{
    RTLSDisplayApplication::serialConnection()->rbootdata=true;
    RTLSDisplayApplication::serialConnection()->writeData("$reset\r\n");

    m_setTimer->start(5);
    if(SerialConnection::Rev_$setok =="$setok")
    {
        QMessageBox::information(this,"Information","Set Success!","Close");
        SerialConnection::Rev_$setok = "";
    }
    else
    {
        m_setTimer->start(1000);
        connect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));
    }


}
void ViewSettingsWidget::on_BTN_tongbu_clicked()
{
    ui->lE_A0X->setText(myGraphicsWidget->ui->anchorTable->item(0,1)->text());
    ui->lE_A0Y->setText(myGraphicsWidget->ui->anchorTable->item(0,2)->text());
    ui->lE_A0Z->setText(myGraphicsWidget->ui->anchorTable->item(0,3)->text());
    ui->lE_A1X->setText(myGraphicsWidget->ui->anchorTable->item(1,1)->text());
    ui->lE_A1Y->setText(myGraphicsWidget->ui->anchorTable->item(1,2)->text());
    ui->lE_A1Z->setText(myGraphicsWidget->ui->anchorTable->item(1,3)->text());
    ui->lE_A2X->setText(myGraphicsWidget->ui->anchorTable->item(2,1)->text());
    ui->lE_A2Y->setText(myGraphicsWidget->ui->anchorTable->item(2,2)->text());
    ui->lE_A2Z->setText(myGraphicsWidget->ui->anchorTable->item(2,3)->text());
    ui->lE_A3X->setText(myGraphicsWidget->ui->anchorTable->item(3,1)->text());
    ui->lE_A3Y->setText(myGraphicsWidget->ui->anchorTable->item(3,2)->text());
    ui->lE_A3Z->setText(myGraphicsWidget->ui->anchorTable->item(3,3)->text());
}

void ViewSettingsWidget::Settimeout()
{
    disconnect(m_setTimer, SIGNAL(timeout()), this, SLOT(Settimeout()));

    if(SerialConnection::Rev_$setok =="$setok" )
   {
     if(fucStatus)
     {
        QMessageBox::information(this,"Information","Set Success!","Close");
        fucStatus = false;
     }
        SerialConnection::Rev_$setok = "";
   }
    else {

        QMessageBox::warning(this,"Warning","The device is not responding, please try again!","Close");
   }


}
void ViewSettingsWidget:: dataupdate()
{
    //if(SerialConnection::role=="TAG"||SerialConnection::role=="ANCHOR")
   {
     ui->lE_model->setText(SerialConnection::model);
     ui->lE_firmware->setText(SerialConnection::firmware);
     ui->lE_role->setText(SerialConnection::role);
     ui->lE_addr->setText(SerialConnection::addr);
     ui->lE_blink->setText(SerialConnection::blink);
     ui->lE_max_anc_num->setText(SerialConnection::max_anc_num);
     ui->lE_max_tag_num->setText(SerialConnection::max_tag_num);
     ui->lE_uwb_data_rate->setText(SerialConnection::uwb_data_rate);
     ui->lE_channel->setText(SerialConnection::channel);
     ui->lE_updata_frequency->setText(SerialConnection::updata_frequency);
     ui->lE_updata_Period->setText(SerialConnection::updata_Period);
     ui->lE_kalmanfilter->setText(SerialConnection::kalmanfilter);
     ui->lE_ant_dly->setText(SerialConnection::ant_dly);
     ui->lE_tx_power->setText(SerialConnection::tx_power);
     ui->lE_use_ext_eeprom->setText(SerialConnection::use_ext_eeprom);
     ui->lE_use_imu->setText(SerialConnection::use_imu);
     ui->lE_use_oled->setText(SerialConnection::use_oled);
     ui->lE_A0X->setText(SerialConnection::A0_x);
     ui->lE_A0Y->setText(SerialConnection::A0_y);
     ui->lE_A0Z->setText(SerialConnection::A0_z);
     ui->lE_A1X->setText(SerialConnection::A1_x);
     ui->lE_A1Y->setText(SerialConnection::A1_y);
     ui->lE_A1Z->setText(SerialConnection::A1_z);
     ui->lE_A2X->setText(SerialConnection::A2_x);
     ui->lE_A2Y->setText(SerialConnection::A2_y);
     ui->lE_A2Z->setText(SerialConnection::A2_z);
     ui->lE_A3X->setText(SerialConnection::A3_x);
     ui->lE_A3Y->setText(SerialConnection::A3_y);
     ui->lE_A3Z->setText(SerialConnection::A3_z);
    }


    if(SerialConnection::role=="TAG")
    {
         ui->BTN_addr->setEnabled(true);
         ui->BTN_jizhan->setEnabled(true);
         ui->BTN_tongbu->setEnabled(true);
         ui->lE_addr->setEnabled(true);
         ui->lE_A0X->setEnabled(true);
         ui->lE_A0Y->setEnabled(true);
         ui->lE_A0Z->setEnabled(true);
         ui->lE_A1X->setEnabled(true);
         ui->lE_A1Y->setEnabled(true);
         ui->lE_A1Z->setEnabled(true);
         ui->lE_A2X->setEnabled(true);
         ui->lE_A2Y->setEnabled(true);
         ui->lE_A2Z->setEnabled(true);
         ui->lE_A3X->setEnabled(true);
         ui->lE_A3Y->setEnabled(true);
         ui->lE_A3Z->setEnabled(true);
     }
     else if(SerialConnection::role=="ANCHOR")
     {
         ui->BTN_addr->setEnabled(false);
         ui->BTN_jizhan->setEnabled(false);
         ui->BTN_tongbu->setEnabled(false);
         ui->lE_addr->setEnabled(false);
         ui->lE_A0X->setEnabled(false);
         ui->lE_A0Y->setEnabled(false);
         ui->lE_A0Z->setEnabled(false);
         ui->lE_A1X->setEnabled(false);
         ui->lE_A1Y->setEnabled(false);
         ui->lE_A1Z->setEnabled(false);
         ui->lE_A2X->setEnabled(false);
         ui->lE_A2Y->setEnabled(false);
         ui->lE_A2Z->setEnabled(false);
         ui->lE_A3X->setEnabled(false);
         ui->lE_A3Y->setEnabled(false);
         ui->lE_A3Z->setEnabled(false);

     }
}
