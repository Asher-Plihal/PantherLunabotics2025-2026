/****************************************************************************
** Meta object code from reading C++ file 'ViewSettingsWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../views/ViewSettingsWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ViewSettingsWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ViewSettingsWidget_t {
    QByteArrayData data[56];
    char stringdata0[918];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ViewSettingsWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ViewSettingsWidget_t qt_meta_stringdata_ViewSettingsWidget = {
    {
QT_MOC_LITERAL(0, 0, 18), // "ViewSettingsWidget"
QT_MOC_LITERAL(1, 19, 16), // "saveViewSettings"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 22), // "connectionStateChanged"
QT_MOC_LITERAL(4, 60, 33), // "SerialConnection::ConnectionS..."
QT_MOC_LITERAL(5, 94, 5), // "state"
QT_MOC_LITERAL(6, 100, 11), // "serialError"
QT_MOC_LITERAL(7, 112, 16), // "updateDeviceList"
QT_MOC_LITERAL(8, 129, 11), // "setLinetext"
QT_MOC_LITERAL(9, 141, 1), // "s"
QT_MOC_LITERAL(10, 143, 7), // "onReady"
QT_MOC_LITERAL(11, 151, 21), // "enableAutoPositioning"
QT_MOC_LITERAL(12, 173, 6), // "enable"
QT_MOC_LITERAL(13, 180, 20), // "floorplanOpenClicked"
QT_MOC_LITERAL(14, 201, 20), // "updateLocationFilter"
QT_MOC_LITERAL(15, 222, 5), // "index"
QT_MOC_LITERAL(16, 228, 15), // "enableFiltering"
QT_MOC_LITERAL(17, 244, 13), // "originClicked"
QT_MOC_LITERAL(18, 258, 12), // "scaleClicked"
QT_MOC_LITERAL(19, 271, 15), // "gridShowClicked"
QT_MOC_LITERAL(20, 287, 17), // "originShowClicked"
QT_MOC_LITERAL(21, 305, 21), // "tagHistoryShowClicked"
QT_MOC_LITERAL(22, 327, 13), // "saveFPClicked"
QT_MOC_LITERAL(23, 341, 22), // "tagAncTableShowClicked"
QT_MOC_LITERAL(24, 364, 17), // "useAutoPosClicked"
QT_MOC_LITERAL(25, 382, 25), // "showGeoFencingModeClicked"
QT_MOC_LITERAL(26, 408, 25), // "showNavigationModeClicked"
QT_MOC_LITERAL(27, 434, 15), // "alarmSetClicked"
QT_MOC_LITERAL(28, 450, 17), // "zone1ValueChanged"
QT_MOC_LITERAL(29, 468, 17), // "zone2ValueChanged"
QT_MOC_LITERAL(30, 486, 17), // "zone1EditFinished"
QT_MOC_LITERAL(31, 504, 17), // "zone2EditFinished"
QT_MOC_LITERAL(32, 522, 28), // "tagHistoryNumberValueChanged"
QT_MOC_LITERAL(33, 551, 14), // "showOriginGrid"
QT_MOC_LITERAL(34, 566, 4), // "orig"
QT_MOC_LITERAL(35, 571, 4), // "grid"
QT_MOC_LITERAL(36, 576, 15), // "getFloorPlanPic"
QT_MOC_LITERAL(37, 592, 8), // "showSave"
QT_MOC_LITERAL(38, 601, 13), // "setTagHistory"
QT_MOC_LITERAL(39, 615, 1), // "h"
QT_MOC_LITERAL(40, 617, 14), // "loggingClicked"
QT_MOC_LITERAL(41, 632, 20), // "connectButtonClicked"
QT_MOC_LITERAL(42, 653, 24), // "on_Tag_size_valueChanged"
QT_MOC_LITERAL(43, 678, 4), // "arg1"
QT_MOC_LITERAL(44, 683, 10), // "dataupdate"
QT_MOC_LITERAL(45, 694, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(46, 716, 20), // "on_socket_pb_clicked"
QT_MOC_LITERAL(47, 737, 7), // "checked"
QT_MOC_LITERAL(48, 745, 22), // "on_BTN_getdata_clicked"
QT_MOC_LITERAL(49, 768, 19), // "on_BTN_addr_clicked"
QT_MOC_LITERAL(50, 788, 10), // "Settimeout"
QT_MOC_LITERAL(51, 799, 25), // "on_BTN_ant_dly_ok_clicked"
QT_MOC_LITERAL(52, 825, 25), // "on_lE_tx_power_ok_clicked"
QT_MOC_LITERAL(53, 851, 22), // "on_BTN_Restore_clicked"
QT_MOC_LITERAL(54, 874, 21), // "on_BTN_jizhan_clicked"
QT_MOC_LITERAL(55, 896, 21) // "on_BTN_tongbu_clicked"

    },
    "ViewSettingsWidget\0saveViewSettings\0"
    "\0connectionStateChanged\0"
    "SerialConnection::ConnectionState\0"
    "state\0serialError\0updateDeviceList\0"
    "setLinetext\0s\0onReady\0enableAutoPositioning\0"
    "enable\0floorplanOpenClicked\0"
    "updateLocationFilter\0index\0enableFiltering\0"
    "originClicked\0scaleClicked\0gridShowClicked\0"
    "originShowClicked\0tagHistoryShowClicked\0"
    "saveFPClicked\0tagAncTableShowClicked\0"
    "useAutoPosClicked\0showGeoFencingModeClicked\0"
    "showNavigationModeClicked\0alarmSetClicked\0"
    "zone1ValueChanged\0zone2ValueChanged\0"
    "zone1EditFinished\0zone2EditFinished\0"
    "tagHistoryNumberValueChanged\0"
    "showOriginGrid\0orig\0grid\0getFloorPlanPic\0"
    "showSave\0setTagHistory\0h\0loggingClicked\0"
    "connectButtonClicked\0on_Tag_size_valueChanged\0"
    "arg1\0dataupdate\0on_pushButton_clicked\0"
    "on_socket_pb_clicked\0checked\0"
    "on_BTN_getdata_clicked\0on_BTN_addr_clicked\0"
    "Settimeout\0on_BTN_ant_dly_ok_clicked\0"
    "on_lE_tx_power_ok_clicked\0"
    "on_BTN_Restore_clicked\0on_BTN_jizhan_clicked\0"
    "on_BTN_tongbu_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ViewSettingsWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      44,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  234,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,  235,    2, 0x0a /* Public */,
       6,    0,  238,    2, 0x0a /* Public */,
       7,    0,  239,    2, 0x0a /* Public */,
       8,    1,  240,    2, 0x0a /* Public */,
      10,    0,  243,    2, 0x09 /* Protected */,
      11,    1,  244,    2, 0x09 /* Protected */,
      13,    0,  247,    2, 0x09 /* Protected */,
      14,    1,  248,    2, 0x09 /* Protected */,
      16,    0,  251,    2, 0x09 /* Protected */,
      17,    0,  252,    2, 0x09 /* Protected */,
      18,    0,  253,    2, 0x09 /* Protected */,
      19,    0,  254,    2, 0x09 /* Protected */,
      20,    0,  255,    2, 0x09 /* Protected */,
      21,    0,  256,    2, 0x09 /* Protected */,
      22,    0,  257,    2, 0x09 /* Protected */,
      23,    0,  258,    2, 0x09 /* Protected */,
      24,    0,  259,    2, 0x09 /* Protected */,
      25,    0,  260,    2, 0x09 /* Protected */,
      26,    0,  261,    2, 0x09 /* Protected */,
      27,    0,  262,    2, 0x09 /* Protected */,
      28,    1,  263,    2, 0x09 /* Protected */,
      29,    1,  266,    2, 0x09 /* Protected */,
      30,    0,  269,    2, 0x09 /* Protected */,
      31,    0,  270,    2, 0x09 /* Protected */,
      32,    1,  271,    2, 0x09 /* Protected */,
      33,    2,  274,    2, 0x09 /* Protected */,
      36,    0,  279,    2, 0x09 /* Protected */,
      37,    1,  280,    2, 0x09 /* Protected */,
      38,    1,  283,    2, 0x09 /* Protected */,
      40,    0,  286,    2, 0x09 /* Protected */,
      41,    0,  287,    2, 0x09 /* Protected */,
      42,    1,  288,    2, 0x09 /* Protected */,
      44,    0,  291,    2, 0x08 /* Private */,
      45,    0,  292,    2, 0x08 /* Private */,
      46,    1,  293,    2, 0x08 /* Private */,
      48,    0,  296,    2, 0x08 /* Private */,
      49,    0,  297,    2, 0x08 /* Private */,
      50,    0,  298,    2, 0x08 /* Private */,
      51,    0,  299,    2, 0x08 /* Private */,
      52,    0,  300,    2, 0x08 /* Private */,
      53,    0,  301,    2, 0x08 /* Private */,
      54,    0,  302,    2, 0x08 /* Private */,
      55,    0,  303,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   34,   35,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,   39,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   43,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   47,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ViewSettingsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ViewSettingsWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->saveViewSettings(); break;
        case 1: _t->connectionStateChanged((*reinterpret_cast< SerialConnection::ConnectionState(*)>(_a[1]))); break;
        case 2: _t->serialError(); break;
        case 3: { int _r = _t->updateDeviceList();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->setLinetext((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->onReady(); break;
        case 6: _t->enableAutoPositioning((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->floorplanOpenClicked(); break;
        case 8: _t->updateLocationFilter((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->enableFiltering(); break;
        case 10: _t->originClicked(); break;
        case 11: _t->scaleClicked(); break;
        case 12: _t->gridShowClicked(); break;
        case 13: _t->originShowClicked(); break;
        case 14: _t->tagHistoryShowClicked(); break;
        case 15: _t->saveFPClicked(); break;
        case 16: _t->tagAncTableShowClicked(); break;
        case 17: _t->useAutoPosClicked(); break;
        case 18: _t->showGeoFencingModeClicked(); break;
        case 19: _t->showNavigationModeClicked(); break;
        case 20: _t->alarmSetClicked(); break;
        case 21: _t->zone1ValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 22: _t->zone2ValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 23: _t->zone1EditFinished(); break;
        case 24: _t->zone2EditFinished(); break;
        case 25: _t->tagHistoryNumberValueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->showOriginGrid((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 27: _t->getFloorPlanPic(); break;
        case 28: _t->showSave((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->setTagHistory((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->loggingClicked(); break;
        case 31: _t->connectButtonClicked(); break;
        case 32: _t->on_Tag_size_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 33: _t->dataupdate(); break;
        case 34: _t->on_pushButton_clicked(); break;
        case 35: _t->on_socket_pb_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->on_BTN_getdata_clicked(); break;
        case 37: _t->on_BTN_addr_clicked(); break;
        case 38: _t->Settimeout(); break;
        case 39: _t->on_BTN_ant_dly_ok_clicked(); break;
        case 40: _t->on_lE_tx_power_ok_clicked(); break;
        case 41: _t->on_BTN_Restore_clicked(); break;
        case 42: _t->on_BTN_jizhan_clicked(); break;
        case 43: _t->on_BTN_tongbu_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ViewSettingsWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ViewSettingsWidget::saveViewSettings)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject ViewSettingsWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ViewSettingsWidget.data,
    qt_meta_data_ViewSettingsWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ViewSettingsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ViewSettingsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ViewSettingsWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ViewSettingsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 44)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 44;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 44)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 44;
    }
    return _id;
}

// SIGNAL 0
void ViewSettingsWidget::saveViewSettings()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
