/****************************************************************************
** Meta object code from reading C++ file 'GraphicsWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../views/GraphicsWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GraphicsWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GraphicsWidget_t {
    QByteArrayData data[60];
    char stringdata0[564];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GraphicsWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GraphicsWidget_t qt_meta_stringdata_GraphicsWidget = {
    {
QT_MOC_LITERAL(0, 0, 14), // "GraphicsWidget"
QT_MOC_LITERAL(1, 15, 15), // "updateAnchorXYZ"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 2), // "id"
QT_MOC_LITERAL(4, 35, 1), // "x"
QT_MOC_LITERAL(5, 37, 5), // "value"
QT_MOC_LITERAL(6, 43, 19), // "updateTagCorrection"
QT_MOC_LITERAL(7, 63, 3), // "aid"
QT_MOC_LITERAL(8, 67, 3), // "tid"
QT_MOC_LITERAL(9, 71, 8), // "centerAt"
QT_MOC_LITERAL(10, 80, 1), // "y"
QT_MOC_LITERAL(11, 82, 10), // "centerRect"
QT_MOC_LITERAL(12, 93, 11), // "visibleRect"
QT_MOC_LITERAL(13, 105, 13), // "setTagHistory"
QT_MOC_LITERAL(14, 119, 1), // "h"
QT_MOC_LITERAL(15, 121, 15), // "centerOnAnchors"
QT_MOC_LITERAL(16, 137, 16), // "anchTableEditing"
QT_MOC_LITERAL(17, 154, 6), // "tagPos"
QT_MOC_LITERAL(18, 161, 5), // "tagId"
QT_MOC_LITERAL(19, 167, 1), // "z"
QT_MOC_LITERAL(20, 169, 8), // "tagStats"
QT_MOC_LITERAL(21, 178, 3), // "r95"
QT_MOC_LITERAL(22, 182, 8), // "tagRange"
QT_MOC_LITERAL(23, 191, 3), // "aId"
QT_MOC_LITERAL(24, 195, 5), // "range"
QT_MOC_LITERAL(25, 201, 8), // "rx_power"
QT_MOC_LITERAL(26, 210, 7), // "anchPos"
QT_MOC_LITERAL(27, 218, 6), // "anchId"
QT_MOC_LITERAL(28, 225, 4), // "show"
QT_MOC_LITERAL(29, 230, 11), // "updatetable"
QT_MOC_LITERAL(30, 242, 15), // "tagTableChanged"
QT_MOC_LITERAL(31, 258, 1), // "r"
QT_MOC_LITERAL(32, 260, 1), // "c"
QT_MOC_LITERAL(33, 262, 18), // "anchorTableChanged"
QT_MOC_LITERAL(34, 281, 15), // "tagTableClicked"
QT_MOC_LITERAL(35, 297, 18), // "anchorTableClicked"
QT_MOC_LITERAL(36, 316, 20), // "itemSelectionChanged"
QT_MOC_LITERAL(37, 337, 23), // "itemSelectionChangedAnc"
QT_MOC_LITERAL(38, 361, 9), // "clearTags"
QT_MOC_LITERAL(39, 371, 17), // "setShowTagHistory"
QT_MOC_LITERAL(40, 389, 18), // "setShowTagAncTable"
QT_MOC_LITERAL(41, 408, 11), // "anchorTable"
QT_MOC_LITERAL(42, 420, 8), // "tagTable"
QT_MOC_LITERAL(43, 429, 10), // "ancTagCorr"
QT_MOC_LITERAL(44, 440, 18), // "showGeoFencingMode"
QT_MOC_LITERAL(45, 459, 3), // "set"
QT_MOC_LITERAL(46, 463, 10), // "zone1Value"
QT_MOC_LITERAL(47, 474, 10), // "zone2Value"
QT_MOC_LITERAL(48, 485, 16), // "tagHistoryNumber"
QT_MOC_LITERAL(49, 502, 4), // "zone"
QT_MOC_LITERAL(50, 507, 6), // "radius"
QT_MOC_LITERAL(51, 514, 3), // "red"
QT_MOC_LITERAL(52, 518, 8), // "setAlarm"
QT_MOC_LITERAL(53, 527, 2), // "in"
QT_MOC_LITERAL(54, 530, 3), // "out"
QT_MOC_LITERAL(55, 534, 9), // "ancRanges"
QT_MOC_LITERAL(56, 544, 3), // "a01"
QT_MOC_LITERAL(57, 548, 3), // "a02"
QT_MOC_LITERAL(58, 552, 3), // "a12"
QT_MOC_LITERAL(59, 556, 7) // "onReady"

    },
    "GraphicsWidget\0updateAnchorXYZ\0\0id\0x\0"
    "value\0updateTagCorrection\0aid\0tid\0"
    "centerAt\0y\0centerRect\0visibleRect\0"
    "setTagHistory\0h\0centerOnAnchors\0"
    "anchTableEditing\0tagPos\0tagId\0z\0"
    "tagStats\0r95\0tagRange\0aId\0range\0"
    "rx_power\0anchPos\0anchId\0show\0updatetable\0"
    "tagTableChanged\0r\0c\0anchorTableChanged\0"
    "tagTableClicked\0anchorTableClicked\0"
    "itemSelectionChanged\0itemSelectionChangedAnc\0"
    "clearTags\0setShowTagHistory\0"
    "setShowTagAncTable\0anchorTable\0tagTable\0"
    "ancTagCorr\0showGeoFencingMode\0set\0"
    "zone1Value\0zone2Value\0tagHistoryNumber\0"
    "zone\0radius\0red\0setAlarm\0in\0out\0"
    "ancRanges\0a01\0a02\0a12\0onReady"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GraphicsWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,  154,    2, 0x06 /* Public */,
       6,    3,  161,    2, 0x06 /* Public */,
       9,    2,  168,    2, 0x06 /* Public */,
      11,    1,  173,    2, 0x06 /* Public */,
      13,    1,  176,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    0,  179,    2, 0x0a /* Public */,
      16,    1,  180,    2, 0x0a /* Public */,
      17,    4,  183,    2, 0x0a /* Public */,
      20,    5,  192,    2, 0x0a /* Public */,
      22,    4,  203,    2, 0x0a /* Public */,
      26,    6,  212,    2, 0x0a /* Public */,
      30,    2,  225,    2, 0x0a /* Public */,
      33,    2,  230,    2, 0x0a /* Public */,
      34,    2,  235,    2, 0x0a /* Public */,
      35,    2,  240,    2, 0x0a /* Public */,
      36,    0,  245,    2, 0x0a /* Public */,
      37,    0,  246,    2, 0x0a /* Public */,
      38,    0,  247,    2, 0x0a /* Public */,
      39,    1,  248,    2, 0x0a /* Public */,
      40,    3,  251,    2, 0x0a /* Public */,
      44,    1,  258,    2, 0x0a /* Public */,
      46,    1,  261,    2, 0x0a /* Public */,
      47,    1,  264,    2, 0x0a /* Public */,
      48,    1,  267,    2, 0x0a /* Public */,
      49,    3,  270,    2, 0x0a /* Public */,
      52,    2,  277,    2, 0x0a /* Public */,
      55,    3,  282,    2, 0x0a /* Public */,
      59,    0,  289,    2, 0x09 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Double,    3,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    7,    8,    5,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    4,   10,
    QMetaType::Void, QMetaType::QRectF,   12,
    QMetaType::Void, QMetaType::Int,   14,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double,   18,    4,   10,   19,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,   18,    4,   10,   19,   21,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double,   18,   23,   24,   25,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Bool, QMetaType::Bool,   27,    4,   10,   19,   28,   29,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   31,   32,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   31,   32,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   31,   32,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   31,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   41,   42,   43,
    QMetaType::Void, QMetaType::Bool,   45,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Double, QMetaType::Bool,   49,   50,   51,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   53,   54,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   56,   57,   58,
    QMetaType::Void,

       0        // eod
};

void GraphicsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GraphicsWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateAnchorXYZ((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 1: _t->updateTagCorrection((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->centerAt((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 3: _t->centerRect((*reinterpret_cast< const QRectF(*)>(_a[1]))); break;
        case 4: _t->setTagHistory((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->centerOnAnchors(); break;
        case 6: _t->anchTableEditing((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->tagPos((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 8: _t->tagStats((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< double(*)>(_a[5]))); break;
        case 9: _t->tagRange((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 10: _t->anchPos((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6]))); break;
        case 11: _t->tagTableChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 12: _t->anchorTableChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 13: _t->tagTableClicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 14: _t->anchorTableClicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 15: _t->itemSelectionChanged(); break;
        case 16: _t->itemSelectionChangedAnc(); break;
        case 17: _t->clearTags(); break;
        case 18: _t->setShowTagHistory((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->setShowTagAncTable((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 20: _t->showGeoFencingMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->zone1Value((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 22: _t->zone2Value((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 23: _t->tagHistoryNumber((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->zone((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 25: _t->setAlarm((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 26: _t->ancRanges((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 27: _t->onReady(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GraphicsWidget::*)(int , int , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsWidget::updateAnchorXYZ)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GraphicsWidget::*)(int , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsWidget::updateTagCorrection)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (GraphicsWidget::*)(double , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsWidget::centerAt)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (GraphicsWidget::*)(const QRectF & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsWidget::centerRect)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (GraphicsWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsWidget::setTagHistory)) {
                *result = 4;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GraphicsWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_GraphicsWidget.data,
    qt_meta_data_GraphicsWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GraphicsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GraphicsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GraphicsWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GraphicsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}

// SIGNAL 0
void GraphicsWidget::updateAnchorXYZ(int _t1, int _t2, double _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void GraphicsWidget::updateTagCorrection(int _t1, int _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void GraphicsWidget::centerAt(double _t1, double _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void GraphicsWidget::centerRect(const QRectF & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void GraphicsWidget::setTagHistory(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
