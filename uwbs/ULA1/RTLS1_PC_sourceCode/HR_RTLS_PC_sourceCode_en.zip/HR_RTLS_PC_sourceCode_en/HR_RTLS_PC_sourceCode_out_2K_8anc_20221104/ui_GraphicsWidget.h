/********************************************************************************
** Form generated from reading UI file 'GraphicsWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRAPHICSWIDGET_H
#define UI_GRAPHICSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "GraphicsView.h"

QT_BEGIN_NAMESPACE

class Ui_GraphicsWidget
{
public:
    QFormLayout *formLayout;
    QTableWidget *anchorTable;
    QTableWidget *tagTable;
    GraphicsView *graphicsView;

    void setupUi(QWidget *GraphicsWidget)
    {
        if (GraphicsWidget->objectName().isEmpty())
            GraphicsWidget->setObjectName(QString::fromUtf8("GraphicsWidget"));
        GraphicsWidget->resize(2201, 517);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(GraphicsWidget->sizePolicy().hasHeightForWidth());
        GraphicsWidget->setSizePolicy(sizePolicy);
        formLayout = new QFormLayout(GraphicsWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        anchorTable = new QTableWidget(GraphicsWidget);
        if (anchorTable->columnCount() < 12)
            anchorTable->setColumnCount(12);
        if (anchorTable->rowCount() < 8)
            anchorTable->setRowCount(8);
        anchorTable->setObjectName(QString::fromUtf8("anchorTable"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(anchorTable->sizePolicy().hasHeightForWidth());
        anchorTable->setSizePolicy(sizePolicy1);
        anchorTable->setMinimumSize(QSize(0, 149));
        anchorTable->setMaximumSize(QSize(350, 350));
        QFont font;
        font.setPointSize(8);
        anchorTable->setFont(font);
        anchorTable->setFrameShape(QFrame::StyledPanel);
        anchorTable->setFrameShadow(QFrame::Sunken);
        anchorTable->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        anchorTable->setAutoScroll(true);
        anchorTable->setAlternatingRowColors(true);
        anchorTable->setGridStyle(Qt::SolidLine);
        anchorTable->setSortingEnabled(false);
        anchorTable->setRowCount(8);
        anchorTable->setColumnCount(12);
        anchorTable->horizontalHeader()->setMinimumSectionSize(15);
        anchorTable->horizontalHeader()->setDefaultSectionSize(15);
        anchorTable->horizontalHeader()->setStretchLastSection(false);
        anchorTable->verticalHeader()->setVisible(false);
        anchorTable->verticalHeader()->setMinimumSectionSize(16);
        anchorTable->verticalHeader()->setDefaultSectionSize(16);
        anchorTable->verticalHeader()->setHighlightSections(true);

        formLayout->setWidget(0, QFormLayout::LabelRole, anchorTable);

        tagTable = new QTableWidget(GraphicsWidget);
        if (tagTable->columnCount() < 15)
            tagTable->setColumnCount(15);
        tagTable->setObjectName(QString::fromUtf8("tagTable"));
        sizePolicy.setHeightForWidth(tagTable->sizePolicy().hasHeightForWidth());
        tagTable->setSizePolicy(sizePolicy);
        tagTable->setMinimumSize(QSize(0, 149));
        tagTable->setMaximumSize(QSize(16777215, 16777215));
        tagTable->setFont(font);
        tagTable->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        tagTable->setAlternatingRowColors(true);
        tagTable->setRowCount(0);
        tagTable->setColumnCount(15);
        tagTable->horizontalHeader()->setMinimumSectionSize(20);
        tagTable->horizontalHeader()->setDefaultSectionSize(20);
        tagTable->horizontalHeader()->setStretchLastSection(false);
        tagTable->verticalHeader()->setMinimumSectionSize(18);
        tagTable->verticalHeader()->setDefaultSectionSize(18);

        formLayout->setWidget(0, QFormLayout::FieldRole, tagTable);

        graphicsView = new GraphicsView(GraphicsWidget);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setMaximumSize(QSize(16777, 16777));

        formLayout->setWidget(1, QFormLayout::SpanningRole, graphicsView);


        retranslateUi(GraphicsWidget);

        QMetaObject::connectSlotsByName(GraphicsWidget);
    } // setupUi

    void retranslateUi(QWidget *GraphicsWidget)
    {
        GraphicsWidget->setWindowTitle(QCoreApplication::translate("GraphicsWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GraphicsWidget: public Ui_GraphicsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRAPHICSWIDGET_H
