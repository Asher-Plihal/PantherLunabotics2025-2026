/********************************************************************************
** Form generated from reading UI file 'connectionwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNECTIONWIDGET_H
#define UI_CONNECTIONWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConnectionWidget
{
public:
    QLabel *label;
    QComboBox *comPort;
    QPushButton *connect_pb;

    void setupUi(QWidget *ConnectionWidget)
    {
        if (ConnectionWidget->objectName().isEmpty())
            ConnectionWidget->setObjectName(QString::fromUtf8("ConnectionWidget"));
        ConnectionWidget->setEnabled(false);
        ConnectionWidget->resize(215, 40);
        ConnectionWidget->setMaximumSize(QSize(16777215, 40));
        label = new QLabel(ConnectionWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(9, 9, 24, 16));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setStyleSheet(QString::fromUtf8(""));
        comPort = new QComboBox(ConnectionWidget);
        comPort->setObjectName(QString::fromUtf8("comPort"));
        comPort->setGeometry(QRect(39, 9, 100, 22));
        comPort->setMinimumSize(QSize(100, 0));
        connect_pb = new QPushButton(ConnectionWidget);
        connect_pb->setObjectName(QString::fromUtf8("connect_pb"));
        connect_pb->setGeometry(QRect(145, 9, 80, 22));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(connect_pb->sizePolicy().hasHeightForWidth());
        connect_pb->setSizePolicy(sizePolicy1);
        connect_pb->setMinimumSize(QSize(50, 22));
        connect_pb->setStyleSheet(QString::fromUtf8(""));

        retranslateUi(ConnectionWidget);

        QMetaObject::connectSlotsByName(ConnectionWidget);
    } // setupUi

    void retranslateUi(QWidget *ConnectionWidget)
    {
        ConnectionWidget->setWindowTitle(QCoreApplication::translate("ConnectionWidget", "Form", nullptr));
        label->setText(QCoreApplication::translate("ConnectionWidget", "\344\270\262\345\217\243", nullptr));
        connect_pb->setText(QCoreApplication::translate("ConnectionWidget", "Connect", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ConnectionWidget: public Ui_ConnectionWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNECTIONWIDGET_H
