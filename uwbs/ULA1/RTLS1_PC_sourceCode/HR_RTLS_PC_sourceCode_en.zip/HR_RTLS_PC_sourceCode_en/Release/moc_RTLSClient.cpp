/****************************************************************************
** Meta object code from reading C++ file 'RTLSClient.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../network/RTLSClient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'RTLSClient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RTLSClient_t {
    QByteArrayData data[35];
    char stringdata0[321];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RTLSClient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RTLSClient_t qt_meta_stringdata_RTLSClient = {
    {
QT_MOC_LITERAL(0, 0, 10), // "RTLSClient"
QT_MOC_LITERAL(1, 11, 7), // "anchPos"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 8), // "anchorId"
QT_MOC_LITERAL(4, 29, 1), // "x"
QT_MOC_LITERAL(5, 31, 1), // "y"
QT_MOC_LITERAL(6, 33, 1), // "z"
QT_MOC_LITERAL(7, 35, 6), // "tagPos"
QT_MOC_LITERAL(8, 42, 5), // "tagId"
QT_MOC_LITERAL(9, 48, 8), // "tagStats"
QT_MOC_LITERAL(10, 57, 3), // "r95"
QT_MOC_LITERAL(11, 61, 8), // "tagRange"
QT_MOC_LITERAL(12, 70, 3), // "aId"
QT_MOC_LITERAL(13, 74, 16), // "statusBarMessage"
QT_MOC_LITERAL(14, 91, 6), // "status"
QT_MOC_LITERAL(15, 98, 21), // "enableAutoPositioning"
QT_MOC_LITERAL(16, 120, 15), // "centerOnAnchors"
QT_MOC_LITERAL(17, 136, 15), // "enableFiltering"
QT_MOC_LITERAL(18, 152, 9), // "ancRanges"
QT_MOC_LITERAL(19, 162, 3), // "a01"
QT_MOC_LITERAL(20, 166, 3), // "a02"
QT_MOC_LITERAL(21, 170, 3), // "a12"
QT_MOC_LITERAL(22, 174, 7), // "onReady"
QT_MOC_LITERAL(23, 182, 11), // "onConnected"
QT_MOC_LITERAL(24, 194, 3), // "ver"
QT_MOC_LITERAL(25, 198, 4), // "conf"
QT_MOC_LITERAL(26, 203, 15), // "updateAnchorXYZ"
QT_MOC_LITERAL(27, 219, 2), // "id"
QT_MOC_LITERAL(28, 222, 5), // "value"
QT_MOC_LITERAL(29, 228, 19), // "updateTagCorrection"
QT_MOC_LITERAL(30, 248, 3), // "aid"
QT_MOC_LITERAL(31, 252, 3), // "tid"
QT_MOC_LITERAL(32, 256, 7), // "newData"
QT_MOC_LITERAL(33, 264, 22), // "connectionStateChanged"
QT_MOC_LITERAL(34, 287, 33) // "SerialConnection::ConnectionS..."

    },
    "RTLSClient\0anchPos\0\0anchorId\0x\0y\0z\0"
    "tagPos\0tagId\0tagStats\0r95\0tagRange\0"
    "aId\0statusBarMessage\0status\0"
    "enableAutoPositioning\0centerOnAnchors\0"
    "enableFiltering\0ancRanges\0a01\0a02\0a12\0"
    "onReady\0onConnected\0ver\0conf\0"
    "updateAnchorXYZ\0id\0value\0updateTagCorrection\0"
    "aid\0tid\0newData\0connectionStateChanged\0"
    "SerialConnection::ConnectionState"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RTLSClient[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    6,   89,    2, 0x06 /* Public */,
       7,    4,  102,    2, 0x06 /* Public */,
       9,    5,  111,    2, 0x06 /* Public */,
      11,    4,  122,    2, 0x06 /* Public */,
      13,    1,  131,    2, 0x06 /* Public */,
      15,    1,  134,    2, 0x06 /* Public */,
      16,    0,  137,    2, 0x06 /* Public */,
      17,    0,  138,    2, 0x06 /* Public */,
      18,    3,  139,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      22,    0,  146,    2, 0x09 /* Protected */,
      23,    2,  147,    2, 0x09 /* Protected */,
      26,    3,  152,    2, 0x09 /* Protected */,
      29,    3,  159,    2, 0x09 /* Protected */,
      32,    0,  166,    2, 0x08 /* Private */,
      33,    1,  167,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Bool, QMetaType::Bool,    3,    4,    5,    6,    2,    2,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double,    8,    4,    5,    6,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,    8,    4,    5,    6,   10,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::ULongLong, QMetaType::Double, QMetaType::Double,    8,   12,    4,    5,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   19,   20,   21,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   24,   25,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Double,   27,    4,   28,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   30,   31,   28,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 34,    2,

       0        // eod
};

void RTLSClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<RTLSClient *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->anchPos((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6]))); break;
        case 1: _t->tagPos((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 2: _t->tagStats((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< double(*)>(_a[5]))); break;
        case 3: _t->tagRange((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 4: _t->statusBarMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->enableAutoPositioning((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->centerOnAnchors(); break;
        case 7: _t->enableFiltering(); break;
        case 8: _t->ancRanges((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 9: _t->onReady(); break;
        case 10: _t->onConnected((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 11: _t->updateAnchorXYZ((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 12: _t->updateTagCorrection((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 13: _t->newData(); break;
        case 14: _t->connectionStateChanged((*reinterpret_cast< SerialConnection::ConnectionState(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (RTLSClient::*)(quint64 , double , double , double , bool , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::anchPos)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(quint64 , double , double , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::tagPos)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(quint64 , double , double , double , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::tagStats)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(quint64 , quint64 , double , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::tagRange)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::statusBarMessage)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::enableAutoPositioning)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::centerOnAnchors)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::enableFiltering)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (RTLSClient::*)(int , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RTLSClient::ancRanges)) {
                *result = 8;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject RTLSClient::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_RTLSClient.data,
    qt_meta_data_RTLSClient,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RTLSClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RTLSClient::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RTLSClient.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int RTLSClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void RTLSClient::anchPos(quint64 _t1, double _t2, double _t3, double _t4, bool _t5, bool _t6)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void RTLSClient::tagPos(quint64 _t1, double _t2, double _t3, double _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void RTLSClient::tagStats(quint64 _t1, double _t2, double _t3, double _t4, double _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void RTLSClient::tagRange(quint64 _t1, quint64 _t2, double _t3, double _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void RTLSClient::statusBarMessage(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void RTLSClient::enableAutoPositioning(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void RTLSClient::centerOnAnchors()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void RTLSClient::enableFiltering()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void RTLSClient::ancRanges(int _t1, int _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
